#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char *argv[])
{
    int pid;
    int currTime, newTime;
    int status;


    //if nothing provide/err case -> message is provided
    if (argc != 2)
    {
        printf("Usage: time <command>\n");
        exit(1);
    }

    //otehrwise -> get curent time with uptime()
    //or we could use time()? BUt professor told to use uptime()
    currTime = uptime();
    //create a copy of process
    pid = fork();

    //fork error -> return -1
    if (pid < 0)
    {
        printf("Fork error\n");
        //exit if error
        exit(1);
    }
    //sucessful fork -> new copy/child
    else if (pid == 0)
    {
        //execute the program using exec()
        //exec fail if < 0
        if (exec(argv[1], argv + 1) < 0){
            printf("Exec error\n");
            exit(1);
        }
        else
        {   
            printf("not failed\n");
            exit(0);
        }
    }
    else
    {
        //child finish -> parent next
        //use wait with status code
        wait(&status);

        //check for status to see if it is error or not
        if(status > 0){
            printf("\n");
            exit(1);
        }else{
            //or we could use time()? BUt professor told to use uptime()
            newTime = uptime();
            printf("\nReal-time in ticks: %d\n", newTime - currTime);
        }
    }

    time();
    return 0;
}