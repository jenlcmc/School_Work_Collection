#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

//call the new sps() system service.
int main(int argc, char *argv[])
{
    sps();

    exit(0);
}