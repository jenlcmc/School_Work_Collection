﻿/* Name = Uyen Tran & Genaro Grillo
 * Section = 1006
 * Description = Implement a coffee shop automated system
 * The text box will be used to read a quantity from the user, the radio buttons will be used to select small,medium,  or large size. 
 * The add total button is used to update the running total for the order,  complete order outputs the order total to the output label, and exit button exits out of the program. 
 * A small cup costs $1.75, medium costs $1.90, and large costs $2.00
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form1 : Form
    {
        //const var for the prices 
        const double SMALL = 1.75;
        const double MEDIUM = 1.90;
        const double LARGE = 2.00;

        //global var to store how many cups 
        int smallS;
        int mediumS;
        int largeS;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //set all radio buttons to unchecked
            Small.Checked = false;
            Medium.Checked = false;
            Large.Checked = false;

            //set add and complete to disable
            btnAdd.Enabled = false;
            btnCompleteOrder.Enabled = false;

            //output == blank
            Output.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
           
            //error case
            if (Small.Checked == false && Medium.Checked == false && Large.Checked == false)
            {
                MessageBox.Show("Please Check A Size");
            }
            else
            {   
                //set data for small cups
                if(Small.Checked == true){
                    int.TryParse(txtQuatity.Text, out smallS);
                    
                }
                //set data for medium cups
                if (Medium.Checked == true)
                {
                    int.TryParse(txtQuatity.Text, out mediumS);

                }
                //set data for large cups
                if (Large.Checked == true)
                {
                    int.TryParse(txtQuatity.Text, out largeS);

                }
            }

            //enable complete order
            btnCompleteOrder.Enabled = true;

            //set radio into unchecked
            Small.Checked = false;
            Medium.Checked = false;
            Large.Checked = false;

            //clear output and set focus to text box 
            txtQuatity.Text = "";
            txtQuatity.Focus();
        }

        private void btnCompleteOrder_Click(object sender, EventArgs e)
        {
            //calculate total
            double total = (SMALL * smallS) + (MEDIUM * mediumS) + (LARGE * largeS);
            //clear out text box 
            txtQuatity.Text = "";
            //output result
            Output.Text = "Small: " + smallS + '\n' + "Medium: " + mediumS + '\n' + "Large: " + largeS + '\n' + "Total: $" + total;
            //disable Comple Order button
            btnCompleteOrder.Enabled = false;
            //set amount of cups to 0
            smallS = 0;
            mediumS = 0;
            largeS = 0;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); //close program
        }

        private void txtQuatity_TextChanged(object sender, EventArgs e)
        {
            //clear output
            Output.Text = "";

            int number = 0;
            //check for valid input
            if(int.TryParse(txtQuatity.Text, out number))
            {
                btnAdd.Enabled = true; //valid
            }
            else
            {
                btnAdd.Enabled = false; //invalid
            }
        }

        private void Output_Click(object sender, EventArgs e)
        {

        }
    }
}
