﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
/* Name: Uyen Tran and Genaro Grillo
 * Section : 1006
 * Description: write a winform project in C# that implements a credit card number check.
 * The following method is used to verify actual credit card numbers but, for simplicity, we will describe it fornumbers with 8 digits instead of 16:
 */

using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Quit_Click = quit program
        private void Quit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Validate the user input
        private void Validate_Click(object sender, EventArgs e)
        {
            // input into str
            string str = txtCardNum.Text;
            
            // convert it into int
            int num = int.Parse(str);
            
            //variables
            int rigthmost = 0;
            int sum1 = 0;
            int sum2 = 0;
            int digit = 0;
            int holder = num;
            const int size = 8;

            // loop for seperate each digit and calculate
            for (int i = 0; i < size; i++)
            {
                rigthmost = num % 10;
                num /= 10;

                // even case
                if (i % 2 == 0)
                {
                    sum1 += rigthmost;
                }
                // odd case
                if (i % 2 == 1)
                {
                    rigthmost *= 2;
                    // split digit of each odd and calculate
                    while (rigthmost != 0)
                    {
                        digit = rigthmost % 10;
                        rigthmost /= 10;
                        sum2 += digit;
                    }
                }
            }

            // calculate whole thing
            int final = sum1 + sum2;

            //validate if it's valid or not
            if (final % 10 == 0) //valid
            {

                label2.Text = "Valid";
            }
            // invalid
            // not work
            else
            {
                int correct = 8 - (final % 10);
                label2.Text = "Invalid. Parity bit should be " + correct.ToString();
            }

        }

        private void CreditNums_Click(object sender, EventArgs e)
        {

        }

        private void txtCardNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
