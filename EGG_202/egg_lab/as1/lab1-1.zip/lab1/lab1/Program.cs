﻿/*
 * Name: Uyen Tran and Genaro Grillo
 * Assignment = Lab 1 - Summer Job
 * Description = Compute multiple values for summer job
 */
using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;



namespace week2

{

    class Program

    {
        /*
         * Tax = Compute tax which is 14% of the total amount
         * double total = total before tax
         * return double tax = total after tax
         */
        static double Tax(double total)

        {

            double tax = (86.0 / 100.0) * total / 1.0;

            return tax;

        }

        /*
         * Clothes = Compute amount spent on clothes which is 10% of the total amount after tax
         * double total = total after tax
         * return double tax = amount spent on clothes
         */
        static double Clothes(double total)

        {

            double clothes = (10.0 / 100.0) * total / 1.0;

            return clothes;

        }

        /*
         * School = Compute amount spent on school which is 1% of the total amount after tax
         * double total = total after tax
         * return double tax = amount spent on school 
         */
        static double School(double total)

        {

            double school = (1.0 / 100.0) * total / 1.0;

            return school;

        }

        /*
         * Saving = Compute amount spent on saving which is 25% of the remaining
         * double total = total remaining
         * return double tax = amount for saving 
         */
        static double Saving(double total)

        {

            double saving = (25.0 / 100.0) * total / 1.0;

            return saving;

        }

        /*
         * Parent = Compute amount parent spent for saving which is $.50 for $1
         * double total = total saving
         * return double tax = amount parent spent 
         */
        static double Parent(double total)

        {

            double parent = total * .50;

            return parent;

        }

        static void Main(string[] args)

        {

            //declare variables and initialize
            const int week = 5;

            double payrate;

            double[] hoursWeek = new double[week];

            double total = 0;

            double afterTax = 0;

            double clothes = 0;

            double supplies = 0;

            double saving = 0;

            double remain = 0;

            double parent = 0;

            double temp = 0;


            //prompt the user and read data
            Console.Write("Please enter payrate $ ");

            payrate = double.Parse(Console.ReadLine());

            //for loop to add user input into array and compute total hours for 5 weeks
            for (int i = 0; i < week; ++i)

            {
                int increment = i + 1;

                Console.Write("Enter hours worked in week " + increment + ": ");

                hoursWeek[i] = double.Parse(Console.ReadLine());

                total += hoursWeek[i];

            }

            //calculate total amount before tax
            total *= payrate;

            //compute after tax
            afterTax = Math.Round(Tax(total), 2);

            //compute for clothes
            clothes = Math.Round(Clothes(afterTax), 2);

            //compute for supplies
            supplies = Math.Round(School(afterTax), 2);

            //compute for remain
            remain = afterTax - clothes - supplies;

            //compute for saving
            saving = Math.Round(Saving(remain), 2);

            //compute for temp
            temp = Math.Floor(Saving(remain));

            //compute for parent
            parent = Math.Round(Parent(temp), 2);

            //output all the values
            Console.WriteLine("\nSummer Budget");

            Console.WriteLine("Income before taxes \t $ \t" + total);

            Console.WriteLine("Income after taxes \t $ \t" + afterTax);

            Console.WriteLine("Cloths         \t \t $ \t" + clothes);

            Console.WriteLine("School supplies \t $ \t" + supplies);

            Console.WriteLine("Saving bonds  \t \t $ \t" + saving);

            Console.WriteLine("Parents savings bonds \t $ \t" + parent.ToString("0.00"));
        }

    }

}